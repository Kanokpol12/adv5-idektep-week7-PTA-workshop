#include "Sensor.h"

Sensor::Sensor(int sensorPin)
{
    sPin = sensorPin;
}

void Sensor::sensorInit()
{
    pinMode(sPin, INPUT);
}

bool Sensor::obDetect()
{
    return digitalRead(sPin) == HIGH;
}