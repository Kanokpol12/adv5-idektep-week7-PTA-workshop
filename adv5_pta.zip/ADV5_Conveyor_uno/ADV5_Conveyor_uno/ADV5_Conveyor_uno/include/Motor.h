#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

class Motor
{
private:
    int mPin1;
    int mPin2;
public:
    Motor(int Pin1, int Pin2);
    void motorInit();
    void conveyorOn();
    void conveyorOff();
};


#endif