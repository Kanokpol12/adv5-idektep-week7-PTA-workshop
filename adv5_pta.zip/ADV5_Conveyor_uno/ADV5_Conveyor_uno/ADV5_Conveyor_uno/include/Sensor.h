#ifndef SENSOR_H
#define SENSOR_H

#include <Arduino.h>

class Sensor
{
private:
    int sPin;
public:
    Sensor(int sensorPin);
    void sensorInit();
    bool obDetect();
};


#endif