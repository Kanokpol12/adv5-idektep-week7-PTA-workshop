#ifndef SERVO_LIB_H
#define SERVO_LIB_H

#include <Arduino.h>

class ServoLib
{
private:
    uint8_t _pin;
    uint8_t _channel;
    uint16_t _freq;
    uint8_t _resolution;
    uint16_t _pulseMin;
    uint16_t _pulseMax;

    uint32_t usToDuty(uint16_t us);
public:
    ServoLib(uint8_t pin = 5, uint8_t pwmChannel = 0,
                    uint16_t freq = 50, uint8_t resolution = 10,
                    uint16_t pulseMin = 500, uint16_t pulseMax = 2400);

    void servoInit();
    void writeAngle(int angle);
    void sweep();
    void grip(int pos);     // grip at angle
    void ungrip(int pos);   // ungrip at angle
};
#endif