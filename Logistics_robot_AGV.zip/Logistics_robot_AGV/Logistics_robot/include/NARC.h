#ifndef NARC_H
#define NARC_H

#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>

class NARC
{
public:
    NARC(const char* mqttServer, int port, const char* clientId, const char* topicPrefix);
    void mqtt_init();
    void mqtt_listen();
    
    void publish_m(const String& topic, const char* message);
    void publish(const char* topic, const char* message);
    void setSubscribeTopic(const String& topic);
    void setOnMessage(std::function<void(const String&, const String&)> cb);
    bool waitForMessage(const String& expectedPayloadSubstring, uint32_t timeout_ms);
    
    volatile bool has_new_msg = false;
    String last_topic, last_payload;
    String topicMessage;
    const char* mqttServer;
private:
    void mqtt_reconnect();
    static void _staticCallback(char* topic, byte* payload, unsigned int length);
    void _onMqtt(char* topic, byte* payload, unsigned int length);
    static NARC* _self;

    const char* clientId;
    int mqttPort;
    WiFiClient espClient;
    PubSubClient client;

    String subscribeTopic;
    std::function<void(const String&, const String&)> onMessage;
};
#endif