#ifndef DIRECTION_H
#define DIRECTION_H

#include <Arduino.h>

class Direction
{
private:
    /* data */
public:
    void runSequence();
};
#endif

