import time, cv2, math
import numpy as np
from decorators import logger 
from utils import message_handle 

# ======================================
# [1] CONFIGURATIONS & OFFSETS
# ======================================

X_OFFSET =  53.50
Y_OFFSET =  25.00+33

# ======================================
# [2] CALCULATION & DETECTION
# ======================================
def shape_detection_case(approx):
    if len(approx) == 3: return "Triangle"
    elif len(approx) == 4: return "Rectangle"
    else: return "Circle"

def object_position_cal(frame, cx, cy, mm_per_pixel=0.3226):
    h, w, _ = frame.shape
    cam_center = (int(w / 2), int(h / 2))
    offset_x_pixel = cx - cam_center[0]
    offset_y_pixel = cy - cam_center[1]
    cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
    cv2.line(frame, cam_center, (cx, cy), (255, 255, 255), 2)
    return int(offset_x_pixel * mm_per_pixel), int(offset_y_pixel * mm_per_pixel)

def object_position_check(data_stream, stamp_choose=1, target_count=10):
    count, last_value = 0, None
    for data in data_stream:
        if data == last_value: count += 1
        else:
            count = 1
            last_value = data
        if count == target_count:
            cam_offset_x, cam_offset_y = data[0], data[1]
            
            # คำนวณพิกัดจริงของหุ่นยนต์ (บวก Offset ระหว่างกล้องและหัวดูด/หนีบ)
            raw_robot_x = cam_offset_x + X_OFFSET
            raw_robot_y = cam_offset_y + Y_OFFSET
            
            # ส่งพิกัดจริงไปเลย ไม่ต้องจัดเข้า Tray
            return f"G{stamp_choose} X{raw_robot_x:.1f} Y{raw_robot_y:.1f}"
    return None 

def color_detection_choose(c_choose, frame):
    frame_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    if c_choose in ["red", "r"]:
        lower1 = np.array([0, 100, 100], dtype=np.uint8); upper1 = np.array([10, 255, 255], dtype=np.uint8)
        lower2 = np.array([160, 100, 100], dtype=np.uint8); upper2 = np.array([179, 255, 255], dtype=np.uint8)
        return cv2.inRange(frame_hsv, lower1, upper1) + cv2.inRange(frame_hsv, lower2, upper2)
    elif c_choose in ["blue", "b"]:
        return cv2.inRange(frame_hsv, np.array([95, 67, 0], dtype=np.uint8), np.array([149, 255, 255], dtype=np.uint8))
    elif c_choose in ["green", "g", "detect green"]: 
        return cv2.inRange(frame_hsv, np.array([35, 40, 40], dtype=np.uint8), np.array([95, 255, 255], dtype=np.uint8)) 
    elif c_choose in ["yellow", "y", "detect yellow"]:
         return cv2.inRange(frame_hsv, np.array([29, 110, 132], dtype=np.uint8), np.array([52, 255, 255], dtype=np.uint8))
    elif c_choose in ["orange", "o", "detect orange"]:
         return cv2.inRange(frame_hsv, np.array([0, 76, 215], dtype=np.uint8), np.array([28, 255, 255], dtype=np.uint8))
    return None

# ======================================
# [3] MAIN CAMERA FUNCTIONS FOR main.py
# ======================================
def camera_preview_display(stop_event, device_num: int):
    """ฟังก์ชันโชว์ภาพจากกล้อง (ใช้ Thread จาก main.py)"""
    cap = cv2.VideoCapture(device_num)
    try:
        logger.info("Starting camera preview..")
        while not stop_event.is_set():
            ret, frame = cap.read()
            if not ret: break
            cv2.imshow("Robot Vision (Preview)", frame)
            if cv2.waitKey(10) & 0xFF == ord("q"): break
    except Exception as e:
        logger.error(f"Camera display thread error: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()

def camera_shape_detection(client, topic, c_choose: str, stamp_choose: str, device_num: int):
    """
    ฟังก์ชันหลักที่ main.py เรียกใช้
    """
    cap = cv2.VideoCapture(device_num)
    data_list = []
    font = cv2.FONT_HERSHEY_SIMPLEX
    preview_duration, timeout = 7, 15
    MIN_OBJECT_AREA = 500

    # จัดการแปลงชื่อสีให้ตรงกับเงื่อนไขใน color_detection_choose
    c_choose_lower = c_choose.lower()

    # --- 1. Preview Phase ---
    start_time = time.time()
    while True:
        ret, frame = cap.read()
        if not ret: return None, None
        
        elapsed_time = time.time() - start_time
        remaining_time = max(0, int(preview_duration - elapsed_time))
        cv2.putText(frame, f"Starting detect in: {remaining_time}s", (20, 50), font, 0.8, (0, 255, 0), 2)
        cv2.imshow('Robot Vision (Process)', frame)   
        
        if elapsed_time > preview_duration or cv2.waitKey(10) & 0xFF == ord("q"):
            break

    # --- 2. Detection Phase ---
    message_handle(client=client, topic=topic, msg="[RPI]:SHAPE DETECTION IS PROCESSING")
    detection_start = time.time()
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret: break
            
            # [CROP ROI] ขยายกรอบให้ครอบคลุมถึงด้านบนนิดนึง (y=50) เผื่อวัตถุอยู่ลึกเข้าไปใต้หัวหนีบ
            roi_frame = frame[50:480, 100:540] 
            
            mask = color_detection_choose(c_choose_lower, roi_frame)
            if mask is None: continue
            
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                c_target = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(c_target)
                
                if area > MIN_OBJECT_AREA:
                    detection_start = time.time() # รีเซ็ตเวลาเมื่อเจอวัตถุ
                    
                    # วิเคราะห์รูปทรง
                    peri = cv2.arcLength(c_target, True)
                    approx = cv2.approxPolyDP(c_target, 0.02*peri, True)
                    shape_detected = shape_detection_case(approx)
                    
                    M = cv2.moments(c_target)
                    if M["m00"] > 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        data = object_position_cal(roi_frame, cx, cy)
                        data_list.append(data)  
                        if len(data_list) > 20: data_list.pop(0)                
                        
                        # คำนวณ G-Code (ใช้พิกัดจริง)
                        try:
                            stamp_num = int(stamp_choose)
                        except ValueError:
                            stamp_num = 1

                        gcode_cmd = object_position_check(data_stream=data_list, stamp_choose=stamp_num, target_count=10)
                        
                        x, y, w, h = cv2.boundingRect(c_target)
                        cv2.rectangle(roi_frame, (x,y), (x+w, y+h), (0,255,0), 2)
                        cv2.putText(roi_frame, f"Shape:{shape_detected}", (x, y-10), font, 0.7, (255, 255, 255), 2)
                        
                        if gcode_cmd:
                            logger.info(f"Shape Detect: '{shape_detected}' | G-Code: '{gcode_cmd}'")
                            # [สำคัญ] รีเทิร์นค่ากลับไปให้ main.py 
                            return str(gcode_cmd), str(shape_detected)

            if time.time() - detection_start > timeout:
                logger.warning("No object detected for 15 seconds. Exiting detection loop.")
                message_handle(client=client, topic=topic, msg="[RPI]:TIMEOUT - NO OBJECT")
                # รีเทิร์นค่ากลับไปให้ main.py (ส่ง home หรือพิกัดหลบภัยกลับไป)
                return "home", None
            
            # วาดกรอบ ROI บนจอหลัก
            cv2.rectangle(frame, (100, 50), (540, 480), (255, 255, 0), 2)
            cv2.imshow("Robot Vision (Process)", frame)
            
            if cv2.waitKey(10) == ord('q'):
                logger.info("Closed Camera by user")
                break
                
    except Exception as e:
        logger.error(f"Error during frame processing: {e}")
        return None, None
    finally:
        cap.release()
        cv2.destroyAllWindows()