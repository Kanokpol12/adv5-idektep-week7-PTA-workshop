import serial, time
from decorators import logger, timeit_log
from utils import message_handle


def init_serial(port):
    return serial.Serial(port=port, baudrate=115200)

def send_state(serial_port, data):
    try:
        if not serial_port or not serial_port.is_open:
            raise serial.SerialException("Port not open")
        serial_port.write(f"{data}".encode('utf-8'))
        time.sleep(0.5)
        logger.info(f"Sent: {data}")
    except serial.SerialException as e:
        logger.error(f"Error sending data: {e}")
        
def receive_state(serial_port):
    state_message = {                             
        "command: Conveyor ON" : 'conveyor-ON',
        "command: Conveyor OFF": 'conveyor-OFF',
        "auto: Conveyor OFF": 'conveyor-detect',
        "Sensor&Motor Init" : 'conveyor-setup',
        "Sethome position" : 'cartesian-complete sethome position',
        "Ready to detect" : 'cartesian-complete detect position',
        "Success to stamp": 'cartesian-complete stamp object',
        "Success to pickup": 'cartesian-complete pickup object'
    }
    # state_message = {}
    try:
        while True:
            if serial_port.in_waiting > 0:
                line = serial_port.readline().decode('utf-8').rstrip()
                logger.info(f"Receive: {line}")
                if line in state_message:
                    return state_message[line]
    except serial.SerialException as e:
        logger.error(f"Serial communication error; {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")
    finally:
        pass


def process_setup(client, conv_port: str, cart_port: str, topic):
    try:
        ser_conv = init_serial(port=conv_port)
        ser_cart = init_serial(port=cart_port)
        if ser_conv.is_open and ser_cart.is_open:
            logger.info("SERIAL PORT IS OPEN AND CONFIGURED.")
            receive_state(serial_port=ser_conv)
            time.sleep(0.1)
            send_state(serial_port=ser_conv,data="conveyor off")
            receive_state(serial_port=ser_conv)
            message_handle(client=client, topic=topic, msg="[CONVEYOR]:SETUP COMPLETE!")
            time.sleep(1)
            send_state(serial_port=ser_cart,data="home")
            receive_state(serial_port=ser_cart)
            time.sleep(1)
            send_state(serial_port=ser_cart, data="ready")
            receive_state(serial_port=ser_cart)
            message_handle(client=client, topic=topic,msg="[CARTESIAN]:SETUP COMPLETE!")
            return ser_conv, ser_cart
    except serial.SerialException as e:
        logger.error(f"Serial communication error: {e}")
    return None, None

