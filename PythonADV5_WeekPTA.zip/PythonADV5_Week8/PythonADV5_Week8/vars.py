#global variable
sub_msg = []

