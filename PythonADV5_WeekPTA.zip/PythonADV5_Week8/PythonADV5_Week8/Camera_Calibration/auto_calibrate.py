import cv2
import numpy as np
import time
import sys
import os

# เพิ่ม path เพื่อให้สามารถดึงฟังก์ชันมาจากโฟลเดอร์ module ได้
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from module.camera_module import object_position_cal, color_detection_choose
from module.serial_module import init_serial, send_state, receive_state

def auto_calibrate(device_num=1, cart_port="COM18"):
    print("="*50)
    print("   [🛠] CARTESIAN CAMERA AUTO-CALIBRATION [🛠]")
    print("="*50)
    
    print(f"\n[1] กำลังเชื่อมต่อแขนกล Cartesian ผ่านพอร์ต {cart_port}...")
    try:
        ser_cart = init_serial(port=cart_port)
        if ser_cart.is_open:
            print("เชื่อมต่อสำเร็จ! รอให้บอร์ด Cartesian บูตสักครู่ (3 วินาที)...")
            time.sleep(3)  # รอให้บอร์ด Reset ตัวเองเสร็จหลังจากเปิดพอร์ต
            
            print("กำลังสั่งแขนกลกลับจุด Home...")
            send_state(serial_port=ser_cart, data="home")
            while receive_state(serial_port=ser_cart) != 'cartesian-complete sethome position':
                pass
                
            print("กำลังขยับแขนกลไปจุด Ready to detect (X=48.5, Y=1.0)...")
            time.sleep(1)
            send_state(serial_port=ser_cart, data="ready")
            while receive_state(serial_port=ser_cart) != 'cartesian-complete detect position':
                pass
            print("แขนกลพร้อมแล้ว!")
        else:
            print(f"[ERROR] ไม่สามารถเปิดพอร์ต {cart_port} ได้ กรุณาเช็คการเชื่อมต่อสาย USB")
            return
    except Exception as e:
        print(f"[ERROR] พอร์ต {cart_port} มีปัญหา: {e}")
        return

    print("\nคำแนะนำ:")
    print("1. แขนกล Cartesian อยู่ที่จุด X=48.5, Y=1.0 เรียบร้อยแล้ว")
    print("2. นำวัตถุ 'สีฟ้า' ไปวางไว้ **ตรงกลางใต้หัวหนีบเป๊ะๆ**")
    print("3. โค้ดจะทำการคำนวณหาค่า X_OFFSET และ Y_OFFSET ให้อัตโนมัติ")
    print("4. กด 'q' เพื่อออก และนำค่าที่ได้ไปใส่ใน camera_module.py")
    print("="*50)

    cap = cv2.VideoCapture(device_num)
    if not cap.isOpened():
        print(f"[ERROR] ไม่สามารถเปิดกล้องเบอร์ {device_num} ได้")
        print("ลองเปลี่ยนเบอร์กล้องในโค้ดบรรทัดล่างสุดดูนะครับ")
        return

    font = cv2.FONT_HERSHEY_SIMPLEX
    MIN_OBJECT_AREA = 500
    TARGET_X = 48.5
    TARGET_Y = 1.0

    # โหลดค่า HSV เริ่มต้น
    import json
    offset_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "offset.json")
    tuned_hsv_lower = np.array([95, 67, 0], dtype=np.uint8)
    tuned_hsv_upper = np.array([149, 255, 255], dtype=np.uint8)
    try:
        with open(offset_file, "r") as f:
            data = json.load(f)
            tuned_hsv_lower = np.array(data.get("BLUE_LOWER", [95, 67, 0]), dtype=np.uint8)
            tuned_hsv_upper = np.array(data.get("BLUE_UPPER", [149, 255, 255]), dtype=np.uint8)
    except: pass

    global_roi_hsv = None
    drawing = False
    ix, iy = -1, -1
    fx, fy = -1, -1
    mouse_selecting = False

    def draw_roi_mouse(event, x, y, flags, param):
        nonlocal drawing, ix, iy, fx, fy, mouse_selecting, tuned_hsv_lower, tuned_hsv_upper, global_roi_hsv
        
        if event == cv2.EVENT_LBUTTONDOWN:
            drawing = True
            mouse_selecting = True
            ix, iy = x, y
            fx, fy = x, y
        elif event == cv2.EVENT_MOUSEMOVE:
            if drawing:
                fx, fy = x, y
        elif event == cv2.EVENT_LBUTTONUP:
            drawing = False
            fx, fy = x, y
            mouse_selecting = False
            
            x_min, x_max = min(ix, fx), max(ix, fx)
            y_min, y_max = min(iy, fy), max(iy, fy)
            
            # แปลงพิกัดจากหน้าจอหลักเป็นพิกัดในกรอบ roi_frame (x=100..540, y=50..480)
            rx_min = max(0, x_min - 100)
            rx_max = min(440, x_max - 100)
            ry_min = max(0, y_min - 50)
            ry_max = min(430, y_max - 50)
            
            if rx_max - rx_min > 5 and ry_max - ry_min > 5 and global_roi_hsv is not None:
                try:
                    selected_hsv = global_roi_hsv[ry_min:ry_max, rx_min:rx_max]
                    # คำนวณค่า Min/Max พร้อมบวก/ลบ ค่า Tolerance เล็กน้อยให้รับสภาพแสงได้
                    # ต้องครอบด้วย int() เพื่อป้องกันปัญหา uint8 Overflow (เช่น 250+40 กลายเป็น 34)
                    h_min_val = max(0, int(np.min(selected_hsv[:,:,0])) - 5)
                    s_min_val = max(0, int(np.min(selected_hsv[:,:,1])) - 40)
                    v_min_val = max(0, int(np.min(selected_hsv[:,:,2])) - 40)
                    
                    h_max_val = min(179, int(np.max(selected_hsv[:,:,0])) + 5)
                    s_max_val = min(255, int(np.max(selected_hsv[:,:,1])) + 40)
                    v_max_val = min(255, int(np.max(selected_hsv[:,:,2])) + 40)
                    
                    tuned_hsv_lower = np.array([h_min_val, s_min_val, v_min_val], dtype=np.uint8)
                    tuned_hsv_upper = np.array([h_max_val, s_max_val, v_max_val], dtype=np.uint8)
                    print(f"\n[TUNE COLOR] จูนสีสำเร็จ! Lower: {tuned_hsv_lower.tolist()} | Upper: {tuned_hsv_upper.tolist()}")
                except Exception as e:
                    print(f"Error tuning HSV: {e}")

    cv2.namedWindow("Calibration Vision")
    cv2.setMouseCallback("Calibration Vision", draw_roi_mouse)

    print("\nกำลังเปิดกล้อง... (กด q ที่หน้าต่างกล้องเพื่อออก)")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            roi_frame = frame[50:480, 100:540] 
            global_roi_hsv = cv2.cvtColor(roi_frame, cv2.COLOR_BGR2HSV)
            
            mask = cv2.inRange(global_roi_hsv, tuned_hsv_lower, tuned_hsv_upper)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if contours:
                c_target = max(contours, key=cv2.contourArea)
                if cv2.contourArea(c_target) > MIN_OBJECT_AREA:
                    M = cv2.moments(c_target)
                    if M["m00"] > 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        cam_offset_x, cam_offset_y = object_position_cal(roi_frame, cx, cy)
                        new_x_offset = TARGET_X - cam_offset_x
                        new_y_offset = TARGET_Y - cam_offset_y
                        
                        x, y, w, h = cv2.boundingRect(c_target)
                        cv2.rectangle(roi_frame, (x,y), (x+w, y+h), (0,255,0), 2)
                        
                        cv2.putText(roi_frame, f"X_OFFSET: {new_x_offset:.1f}", (10, 30), font, 0.7, (0, 255, 255), 2)
                        cv2.putText(roi_frame, f"Y_OFFSET: {new_y_offset:.1f}", (10, 60), font, 0.7, (0, 255, 255), 2)
                        
                        frame[50:480, 100:540] = roi_frame

            cv2.rectangle(frame, (100, 50), (540, 480), (255, 255, 0), 2)
            cv2.putText(frame, "Use MOUSE to draw a box over the object to Tune Color!", (20, 25), font, 0.6, (0, 0, 255), 2)
            cv2.putText(frame, "Press 's' to SAVE Offset & HSV, 'q' to Quit", (20, 470), font, 0.6, (0, 255, 0), 2)
            
            if drawing or mouse_selecting:
                cv2.rectangle(frame, (ix, iy), (fx, fy), (0, 0, 255), 2)
                
            cv2.imshow("Calibration Vision", frame)
            
            key = cv2.waitKey(10) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                if 'new_x_offset' in locals() and 'cx' in locals():
                    print("\n[CALIBRATING] กำลังขยับแขนกล X+10mm เพื่อคำนวณสัดส่วน MM_PER_PIXEL อัตโนมัติ...")
                    cx1 = cx
                    
                    # ขยับไปที่ X=58.5
                    send_state(serial_port=ser_cart, data="X58.5 Y1.0 Z160")
                    time.sleep(3) # รอให้ขยับเสร็จ
                    
                    # อ่านภาพใหม่ (ล้าง Buffer เก่าทิ้งก่อน)
                    for _ in range(10): cap.read()
                        
                    cx2 = cx1
                    ret2, new_frame = cap.read()
                    if ret2:
                        new_roi = new_frame[50:480, 100:540]
                        new_hsv = cv2.cvtColor(new_roi, cv2.COLOR_BGR2HSV)
                        new_mask = cv2.inRange(new_hsv, tuned_hsv_lower, tuned_hsv_upper)
                        new_contours, _ = cv2.findContours(new_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                        if new_contours:
                            c_new = max(new_contours, key=cv2.contourArea)
                            M_new = cv2.moments(c_new)
                            if M_new["m00"] > 0:
                                cx2 = int(M_new["m10"] / M_new["m00"])
                    
                    pixel_diff = abs(cx2 - cx1)
                    if pixel_diff > 0:
                        mm_per_pixel = 10.0 / pixel_diff
                    else:
                        mm_per_pixel = 0.3459 # Fallback
                        
                    print(f"[CALIBRATING] คำนวณ MM_PER_PIXEL ได้: {mm_per_pixel:.4f} (จากระยะ {pixel_diff} พิกเซล)")
                    
                    # ถอยกลับมาที่ Ready
                    print("[CALIBRATING] กำลังถอยแขนกลกลับจุดเดิม...")
                    send_state(serial_port=ser_cart, data="X48.5 Y1.0 Z160")
                    time.sleep(3)
                    
                    try:
                        with open(offset_file, "r") as f:
                            data = json.load(f)
                    except: data = {}
                    
                    data["X_OFFSET"] = round(new_x_offset, 2)
                    data["Y_OFFSET"] = round(new_y_offset, 2)
                    data["BLUE_LOWER"] = tuned_hsv_lower.tolist()
                    data["BLUE_UPPER"] = tuned_hsv_upper.tolist()
                    data["MM_PER_PIXEL"] = round(mm_per_pixel, 4)
                    
                    with open(offset_file, "w") as f:
                        json.dump(data, f, indent=4)
                        
                    print(f"\n[SUCCESS] บันทึกค่า Offset, HSV และ MM_PER_PIXEL ใหม่สำเร็จ!")
                    print(f"X_OFFSET = {new_x_offset:.2f}, Y_OFFSET = {new_y_offset:.2f}, MM_PER_PIXEL = {mm_per_pixel:.4f}")
                    print(f"BLUE_LOWER = {tuned_hsv_lower.tolist()} | BLUE_UPPER = {tuned_hsv_upper.tolist()}")
                    break
                else:
                    print("ยังไม่พบวัตถุ กรุณาวางวัตถุและลากเมาส์คลุมก่อนกดบันทึก!")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    # ใส่เบอร์กล้อง และ พอร์ตของ Cartesian ที่นี่
    auto_calibrate(device_num=1, cart_port="COM18")
