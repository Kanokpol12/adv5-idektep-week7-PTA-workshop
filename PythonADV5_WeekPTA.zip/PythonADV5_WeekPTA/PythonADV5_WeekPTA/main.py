#main
import time, threading, vars
from decorators import logger, timeit_log
from utils import parse_data, message_handle
from module.mqtt_module import connect_mqtt, on_publish, MQTT_TOPIC
from module.camera_module import camera_shape_detection, camera_preview_display
from module.serial_module import process_setup, send_state, receive_state

def adv_control(client, device_num=1, conv_port="COM999", cart_port="COM888"):
    ser_cart, ser_conv = None, None
    run_sc0, run_sc1, run_sc2 = False, False, False
    stop_event = threading.Event()
    cartesian_status = None
    case = ["Detect green", "Detect red", "Detect yellow", "Detect blue"]
    
    try:
        message_handle(client=client, topic=MQTT_TOPIC["RST_TOPIC"], msg=f"RESET")
        ser_conv, ser_cart = process_setup(client=client, conv_port=conv_port, cart_port=cart_port, topic=MQTT_TOPIC["UI_TOPIC"])
        message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="WAITING DATA FROM MQTT.!")
        
        current_step = 0
        
        while True:
            try: 
                if len(vars.sub_msg) > 0:
                    msg = vars.sub_msg.pop(0)
                    
                    if current_step == 0:
                        # --- จังหวะที่ 1: รถวิ่งมาถึงส่ง Detect ครั้งที่ 1 (ข้อความแรกสุด) ---
                        if msg in case:
                            c_choose, s_choose = parse_data(msg)
                            message_handle(client=client, topic=MQTT_TOPIC["COL_TOPIC"], msg=f"{c_choose}")
                            
                            # Debounce: wait 1 second to absorb any duplicate messages and clear them
                            time.sleep(1)
                            vars.sub_msg.clear()
                            
                            current_step = 1
                            
                    elif current_step == 1:
                        # --- จังหวะที่ 2: รถขยับส่ง Detect ครั้งที่ 2 -> Conveyor ON -> ส่ง Go -> ผ่าน IR -> เปิดกล้อง ---
                        if msg in case:
                            # Debounce duplicate messages
                            time.sleep(1)
                            vars.sub_msg.clear()
                            
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[AGV]:MOVE TO LOADING ZONE!")
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[CONVEYOR]:OBJECT IN LOADING ZONE!")
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[CONVEYOR]:START LOAD!")
                            time.sleep(0.5)
                            
                            # สายพานดึงของเข้า
                            send_state(serial_port=ser_conv, data="conveyor on")
                            receive_state(serial_port=ser_conv)
                            time.sleep(0.5)
                            
                            # ส่ง go ให้ AGV วิ่งต่อไปเลย (ส่งซ้ำ 3 รอบกันข้อความสูญหายกลางทาง เหมือน go2)
                            for _ in range(3):
                                msg_pub = client.publish(MQTT_TOPIC["CONTROL_TOPIC"], "go")     
                                on_publish(msg_pub, MQTT_TOPIC["CONTROL_TOPIC"], "go")
                                time.sleep(1)
                            
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[AGV]:MOVE TO UNLOADING ZONE!")
                            
                            # รันสายพานหา IR
                            send_state(serial_port=ser_conv, data="auto")
                            receive_state(serial_port=ser_conv)
                            send_state(serial_port=ser_conv, data="conveyor off")
                            receive_state(serial_port=ser_conv)
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[CONVEYOR]:OBJECT IN DETECT ZONE!")
                            
                            # เปิดกล้องหาตำแหน่ง (แก้ไขเรื่องกล้องชนกัน)
                            shape_coor, shape_ob = camera_shape_detection(client=client, topic=MQTT_TOPIC["UI_TOPIC"], c_choose=c_choose, stamp_choose=s_choose, device_num=device_num)
                            
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[RPI]:SHAPE DETECTION END PROCESS")
                            
                            # ส่งพิกัดให้แขนกล
                            if shape_coor and shape_ob:
                                message_handle(client=client, topic=MQTT_TOPIC["SHAPE_TOPIC"], msg=f"{shape_ob}")
                                message_handle(client=client, topic=MQTT_TOPIC["COOR_TOPIC"], msg=f"{shape_coor}")
                                send_state(serial_port=ser_cart, data=shape_coor)
                                cartesian_status = receive_state(serial_port=ser_cart)
                            else:
                                cartesian_status = "failed"
                                
                            current_step = 2

                    elif current_step == 2:
                        # --- จังหวะที่ 3: รถไปถึงจุดสีเขียวส่ง Detect ครั้งที่ 3 -> เช็คแขนกล -> ส่ง Go2 ---
                        if msg in case:
                            # Debounce duplicate messages
                            time.sleep(1)
                            vars.sub_msg.clear()
                            
                            if cartesian_status == 'cartesian-complete pickup object':
                                message_handle(client=client, topic=MQTT_TOPIC["OBS_TOPIC"], msg="[RPI]:OBJECT DETECT COMPLETE!")
                                
                                # ส่ง go2 ซ้ำ 3 รอบกันข้อความสูญหายกลางทาง (QoS 0)
                                for _ in range(3):
                                    msg_pub = client.publish(MQTT_TOPIC["CONTROL_TOPIC"], "go2")     
                                    on_publish(msg_pub, MQTT_TOPIC["CONTROL_TOPIC"], "go2")
                                    time.sleep(1)
                                    
                                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[AGV]:MOVE TO END POINT")
                            else:
                                message_handle(client=client, topic=MQTT_TOPIC["OBS_TOPIC"], msg="[RPI]:OBJECT IS NOT DETECT!")
                                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[CONVEYOR]:START UNLOAD!")                          
                                
                                # สั่งสายพานทิ้งของ
                                send_state(serial_port=ser_conv, data="conveyor on")
                                receive_state(serial_port=ser_conv)
                                send_state(serial_port=ser_conv, data="auto")
                                receive_state(serial_port=ser_conv)
                                send_state(serial_port=ser_conv, data="conveyor off")
                                receive_state(serial_port=ser_conv)
                                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[CONVEYOR]:OBJECT IN UNLOADING ZONE!")
                                
                                # สั่ง AGV กลับ (ส่งซ้ำ 3 รอบกันสูญหาย)
                                for _ in range(3):
                                    msg_pub = client.publish(MQTT_TOPIC["CONTROL_TOPIC"], "go2")   
                                    on_publish(msg_pub, MQTT_TOPIC["CONTROL_TOPIC"], "go2")
                                    time.sleep(1)
                                
                                message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="[AGV]:MOVE TO END POINT")
                                
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="COMPLETE PROCESS")
                            
                            # เริ่มต้นรอบใหม่
                            current_step = 0
                            message_handle(client=client, topic=MQTT_TOPIC["UI_TOPIC"], msg="WAITING DATA FROM MQTT.! (NEXT ROUND)")
                else:
                    # ป้องกัน CPU รันลูปหนักเกินไปเมื่อไม่มีข้อความ
                    time.sleep(0.1)
                        
            except Exception as e:
                logger.error(f"Error inside loop: {e}")
                time.sleep(1)
                
    except Exception as e:
        logger.error(f"Main setup error : {e}")
    except KeyboardInterrupt:
        logger.warning("Stopped by user.")
    finally:
        if ser_cart: ser_cart.close()
        if ser_conv: ser_conv.close()

def run():
    client = connect_mqtt()
    client.subscribe(MQTT_TOPIC["COLOR_TOPIC"])
    client.loop_start()
    adv_control(client=client)

if __name__ == '__main__':
    run()